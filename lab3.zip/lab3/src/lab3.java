import javax.swing.*;
import java.awt.*;
import java.awt.geom.Point2D;
import java.awt.geom.CubicCurve2D;

public class lab3 extends JFrame {
    public lab3() {
        setSize(400, 300);
        setVisible(true);
    }

    public void paint(Graphics Graphics) {
        Point2D.Double p11 = new Point2D.Double(20, 90);
        Point2D.Double p12 = new Point2D.Double(65, 90);
        Point2D.Double p13 = new Point2D.Double(80, 165);
        Point2D.Double p14 = new Point2D.Double(100, 90);
        Point2D.Double p15 = new Point2D.Double(140, 90);
        Point2D.Double p16 = new Point2D.Double(165, 165);
        Point2D.Double p17 = new Point2D.Double(180, 90);
        Point2D.Double p18 = new Point2D.Double(220, 90);
        Point2D.Double p19 = new Point2D.Double(190, 230);
        Point2D.Double p110 = new Point2D.Double(150, 230);
        Point2D.Double p111 = new Point2D.Double(120, 140);
        Point2D.Double p112 = new Point2D.Double(100, 230);
        Point2D.Double p113 = new Point2D.Double(55, 230);

        CubicCurve2D.Double k11 = new CubicCurve2D.Double(p11.x, p11.y, p11.x, p11.y, p12.x, p12.y, p12.x, p12.y);
        CubicCurve2D.Double k12 = new CubicCurve2D.Double(p12.x, p12.y, p12.x, p12.y, p13.x, p13.y, p13.x, p13.y);
        CubicCurve2D.Double k13 = new CubicCurve2D.Double(p13.x, p13.y, p13.x, p13.y, p14.x, p14.y, p14.x, p14.y);
        CubicCurve2D.Double k14 = new CubicCurve2D.Double(p14.x, p14.y, p14.x, p14.y, p15.x, p15.y, p15.x, p15.y);
        CubicCurve2D.Double k15 = new CubicCurve2D.Double(p15.x, p15.y, p15.x, p15.y, p16.x, p16.y, p16.x, p16.y);
        CubicCurve2D.Double k16 = new CubicCurve2D.Double(p16.x, p16.y, p16.x, p16.y, p17.x, p17.y, p17.x, p17.y);
        CubicCurve2D.Double k17 = new CubicCurve2D.Double(p17.x, p17.y, p17.x, p17.y, p18.x, p18.y, p18.x, p18.y);
        CubicCurve2D.Double k18 = new CubicCurve2D.Double(p18.x, p18.y, p18.x, p18.y, p19.x, p19.y, p19.x, p19.y);
        CubicCurve2D.Double k19 = new CubicCurve2D.Double(p19.x, p19.y, p19.x, p19.y, p110.x, p110.y, p110.x, p110.y);
        CubicCurve2D.Double k110 = new CubicCurve2D.Double(p110.x, p110.y, p110.x, p110.y, p111.x, p111.y, p111.x, p111.y);
        CubicCurve2D.Double k111 = new CubicCurve2D.Double(p111.x, p111.y, p111.x, p111.y, p112.x, p112.y, p112.x, p112.y);
        CubicCurve2D.Double k112 = new CubicCurve2D.Double(p112.x, p112.y, p112.x, p112.y, p113.x, p113.y, p113.x, p113.y);
        CubicCurve2D.Double k113 = new CubicCurve2D.Double(p113.x, p113.y, p113.x, p113.y, p11.x, p11.y, p11.x, p11.y);
        


        Point2D.Double p21 = new Point2D.Double(310, 90);
        Point2D.Double p22 = new Point2D.Double(310, 230);
        Point2D.Double c21 = new Point2D.Double(400, 90);
        Point2D.Double c22 = new Point2D.Double(400, 230);
        Point2D.Double p23 = new Point2D.Double(300, 120);
        Point2D.Double p24 = new Point2D.Double(300, 200);
        Point2D.Double c23 = new Point2D.Double(360, 120);
        Point2D.Double c24 = new Point2D.Double(360, 200);
        Point2D.Double p25 = new Point2D.Double(270, 90);
        Point2D.Double p26 = new Point2D.Double(270, 230);

        CubicCurve2D.Double k21 = new CubicCurve2D.Double(p21.x, p21.y, c21.x, c21.y, c22.x, c22.y, p22.x, p22.y);
        CubicCurve2D.Double k22 = new CubicCurve2D.Double(p23.x, p23.y, c23.x, c23.y, c24.x, c24.y, p24.x, p24.y);
        CubicCurve2D.Double k23 = new CubicCurve2D.Double(p23.x, p23.y, p23.x, p23.y, p24.x, p24.y, p24.x, p24.y);
        CubicCurve2D.Double k24 = new CubicCurve2D.Double(p21.x, p21.y, p21.x, p21.y, p25.x, p25.y, p25.x, p25.y);
        CubicCurve2D.Double k25 = new CubicCurve2D.Double(p22.x, p22.y, p22.x, p22.y, p26.x, p26.y, p26.x, p26.y);
        CubicCurve2D.Double k26 = new CubicCurve2D.Double(p25.x, p25.y, p25.x, p25.y, p26.x, p26.y, p26.x, p26.y);


        Graphics2D Graphics2D = (Graphics2D) Graphics;
        Graphics2D.draw(k11);
        Graphics2D.draw(k12);
        Graphics2D.draw(k13);
        Graphics2D.draw(k14);
        Graphics2D.draw(k15);
        Graphics2D.draw(k16);
        Graphics2D.draw(k17);
        Graphics2D.draw(k18);
        Graphics2D.draw(k19);
        Graphics2D.draw(k110);
        Graphics2D.draw(k111);
        Graphics2D.draw(k112);
        Graphics2D.draw(k113);

        Graphics2D.draw(k21);
        Graphics2D.draw(k22);
        Graphics2D.draw(k23);
        Graphics2D.draw(k24);
        Graphics2D.draw(k25);
        Graphics2D.draw(k26);
    }

    public static void main(String[] args) {
        new lab3();
    }
}